# moodmusic
A python library for music recommendation based on mood classification


