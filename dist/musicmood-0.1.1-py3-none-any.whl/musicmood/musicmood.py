def test():
	print("musicmood module imported succesfully")
